import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';
import { StorageService } from '../services/storage.service';

@Component({
  selector: 'app-carrito',
  templateUrl: './carrito.page.html',
  styleUrls: ['./carrito.page.scss'],
})
export class CarritoPage implements OnInit {
  
  productes: any[] = [];
  productesPerPujar : any[] = [];
  idsProductes : any[] = [];

  // product : any [] = [];

  constructor( public apiService: ApiService, private storage:StorageService) { }

  

  ngOnInit() {
    console.log("hemos entrado en carrito")
    this.getProductsLocalStorage();
   // this.getData();
  }
  async deleteProductToCart(identifier: string) {
    const productesLS = localStorage.getItem('productes');
    if (productesLS !== null) {
      this.idsProductes = JSON.parse(productesLS);
      console.log("after parse");
    } else {
      this.idsProductes = [];
      console.log("no habia nada que añadir")
    }
  
    console.log("els productes son " + this.idsProductes)
  
    const index = this.idsProductes.findIndex((object: { id: string; }) => {
      return object.id === identifier;
    });
  
    console.log(index);
  
    if (index !== -1) {
      this.idsProductes.splice(index, 1); // Remove the product at the found index
    }
  
    const newProductesToPush = JSON.stringify(this.idsProductes);
    localStorage.setItem("productes", newProductesToPush);
    console.log(localStorage);
    console.log("Producto eliminado del carrito");
    window.location.reload();

    // Optionally, update the storage mechanism you're using (e.g., this.storage.set) to remove the product ID
  }
  async decreaseQty(identifier: string) {
    const productesLS = localStorage.getItem('productes');
    if (productesLS !== null) {
      this.idsProductes = JSON.parse(productesLS);
      console.log("after parse");
    } else {
      this.idsProductes = [];
      console.log("no había nada que añadir");
    }
    console.log("los productos son " + JSON.stringify(this.idsProductes));
    
    const index = this.idsProductes.findIndex((object: { id: string; }) => {
      return object.id === identifier;
    });
  
    console.log(index);
  
    if (index === -1) {
      this.idsProductes.push({ 'id': identifier, 'qty': 1 });
    } else {
      this.idsProductes[index].qty--;
    }
    if (this.idsProductes[index].qty == 0){
      this.deleteProductToCart(identifier);
    }
  
    const newProductesToPush = JSON.stringify(this.idsProductes);
    localStorage.setItem("productes", newProductesToPush);
    console.log(localStorage);
    console.log("¡Lo conseguimos!");
    await this.storage.set("productes", identifier);
    window.location.reload();

  }


  
  async increaseQty(identifier: string) {
    const productesLS = localStorage.getItem('productes');
    if (productesLS !== null) {
      this.idsProductes = JSON.parse(productesLS);
      console.log("after parse");
    } else {
      this.idsProductes = [];
      console.log("no había nada que añadir");
    }
    console.log("los productos son " + JSON.stringify(this.idsProductes));
    
    const index = this.idsProductes.findIndex((object: { id: string; }) => {
      return object.id === identifier;
    });
  
    console.log(index);
  
    if (index === -1) {
      this.idsProductes.push({ 'id': identifier, 'qty': 1 });
    } else {
      this.idsProductes[index].qty++;
    }
  
    const newProductesToPush = JSON.stringify(this.idsProductes);
    localStorage.setItem("productes", newProductesToPush);
    console.log(localStorage);
    console.log("¡Lo conseguimos!");
    await this.storage.set("productes", identifier);
    window.location.reload();

  }

  //1. conseguir array de los productos del local storage
  public async getProductsLocalStorage(){
    await this.storage.get("productes");
    const productesLS = localStorage.getItem('productes');
    if (productesLS !== null) {
      this.productes = JSON.parse(productesLS);
    } else {
      this.productes = [];
    }
    console.log("klk")
    console.log(this.productes);
    this.getProductsFromArray();
  }

  remove(index: number) {
    this.productes.splice(index, 1);
  }
  //2. Hacer llamadas a la api de cada producto del local storage

    getProductsFromArray(){
    console.log("klk parsero")
    this.productes.forEach(producte => {
      console.log(producte.id);
      if (producte.id){
        this.apiService.getProduct(producte.id).subscribe((response: any) => {
          const product = response.products[0];
          const productPrice = parseFloat(Number(product.price).toFixed(2));
          product.price = productPrice;
          product.id = producte.id;
          product.qty = producte.qty;
          console.log(product);
          this.productesPerPujar.push(product);
        });
      }
    });
    this.productes = this.productesPerPujar;
    console.log(this.productes);
  }


}
