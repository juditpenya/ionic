import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from '../api.service';
import { StorageService } from '../services/storage.service';


@Component({
  selector: 'app-detail',
  templateUrl: './detail.page.html',
  styleUrls: ['./detail.page.scss'],
})
export class DetailPage implements OnInit {
  
  idsProductes:any = [];
  id;
  product: any = [];
  imgProduct: any = [];

  constructor(private route: ActivatedRoute, public apiService: ApiService, private storage:StorageService) {
    if (this.route.snapshot.paramMap.get("id")!= null){
      this.id = this.route.snapshot.paramMap.get("id");
      console.log(this.id);
    }
  }

  
  ngOnInit() {
      this.getData();
  }

 getData(){
    if (this.id){
      this.apiService.getProduct(this.id).subscribe((response: any) => {
        this.product = response.products[0];
      });

    }
  }


  
  // async addProductToCart() {
  //   console.log("hola");
  //   this.localStorageProducts = localStorage.getItem("products");
  //   if(this.localStorageProducts != null){
  //     console.log("No és null")
  //     console.log(this.localStorageProducts);
  //     this.idsProductes = JSON.parse(this.localStorageProducts);
  //     console.log("els ids productes son " + this.idsProductes);
  //   } else{
  //     console.log("no hi ha localstorage")
  //     console.log("els ids productes son " + this.idsProductes);
  //   }

  //   const index = this.idsProductes.findIndex((object: { id: string; }) => {
  //     return object.id === this.id;
  //   });

  //   console.log(index);

  //   if(index === -1){
  //     this.idsProductes.push({'id': this.id, 'qty' : 1}) 
  //   }else{
  //     this.idsProductes[index].qty ++
  //   }

  //   this.idsProductes = JSON.stringify(this.idsProductes);
  //   localStorage.setItem("products",this.idsProductes);
  //   console.log(this.idsProductes);
      
  //   await this.storage.set("products", this.id);
  //   }

    
    
    //ver si en el local storage se ha añadido cualquier producto

    //JSON STRINGFY Para hacer el set
    //get --> json.parse(ls)

    async addProductToCart() {
      const productesLS = localStorage.getItem('productes');
      if(productesLS !== null){
        this.idsProductes = JSON.parse(productesLS);
        console.log("after parse");
      } else{
        this.idsProductes = [];
        console.log("no habia nada que añadir")
      }
      console.log("els productes son " + this.idsProductes)
      const index = this.idsProductes.findIndex((object: { id: string; }) => {
            return object.id === this.id;
          });
      
          console.log(index);
      
          if(index === -1){
            this.idsProductes.push({'id': this.id, 'qty' : 1}) 
          }else{
            this.idsProductes[index].qty ++
          }
      const newProductesToPush = JSON.stringify(this.idsProductes);
      localStorage.setItem("productes", newProductesToPush);
      console.log(localStorage);
      console.log("lo conseguimos!")
      await this.storage.set("productes", this.id);

    }

    async deleteProductToCart() {
      const productesLS = localStorage.getItem('productes');
      if (productesLS !== null) {
        this.idsProductes = JSON.parse(productesLS);
        console.log("after parse");
      } else {
        this.idsProductes = [];
        console.log("no habia nada que añadir")
      }
    
      console.log("els productes son " + this.idsProductes)
    
      const index = this.idsProductes.findIndex((object: { id: string; }) => {
        return object.id === this.id;
      });
    
      console.log(index);
    
      if (index !== -1) {
        this.idsProductes.splice(index, 1); // Remove the product at the found index
      }
    
      const newProductesToPush = JSON.stringify(this.idsProductes);
      localStorage.setItem("productes", newProductesToPush);
      console.log(localStorage);
      console.log("Producto eliminado del carrito");
    
      // Optionally, update the storage mechanism you're using (e.g., this.storage.set) to remove the product ID
    }
  
}
