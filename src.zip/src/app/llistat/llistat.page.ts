import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-llistat',
  templateUrl: './llistat.page.html',
  styleUrls: ['./llistat.page.scss'],
})
export class LlistatPage implements OnInit {
  productes: any;

  constructor(public apiService: ApiService) {}


  ngOnInit() {
    this.getData();
  }
 getData(){
    this.apiService.getProducts().subscribe((response:any) => {
      this.productes = response.products; 
      this.fixProductPrices(); 
    });
  }

  

  remove(index: number) {
    this.productes.splice(index, 1);
  }

  fixProductPrices() {
    for (let i = 0; i < this.productes.length; i++) {
      const producte = this.productes[i];
      producte.price = parseFloat(Number(producte.price).toFixed(2));
    }
  }
  
}
