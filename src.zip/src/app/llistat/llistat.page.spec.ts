import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LlistatPage } from './llistat.page';

describe('LlistatPage', () => {
  let component: LlistatPage;
  let fixture: ComponentFixture<LlistatPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(LlistatPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
