import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  public appPages = [
    { title: 'Llistat', url: '/llistat', icon: 'albums' },
    { title: 'Carrito', url: '/carrito', icon: 'basket' },
  ];
  public labels = [];
  constructor() {}
}
