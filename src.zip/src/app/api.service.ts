import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class ApiService {
  key = "DLE4EUM5NE65Q6XATQXMN9UM4M373ILR";
  constructor(public http: HttpClient) { }
  //me queda pendiente definir cual es la KEY
  getProducts(){
    return this.http.get(`https://juditp.cat/project/api/products/?display=[id,id_default_image,description,name,price]&output_format=JSON&ws_key=${this.key}`);
  }

  getProduct(id: string){
    return this.http.get(`http://juditp.cat/project/api/products/${id}?display=[name, price, description, id_default_image]&output_format=JSON&ws_key=${this.key}`);
  }

  getImatge(id:string, imgID: string){
    console.log(id,imgID);
    return this.http.get(`https://juditp.cat/project/api/images/products/21/24?ws_key=${this.key}`)
    // return this.http.get(`https://juditp.cat/project/api/images/products/${id}/${imgID}?ws_key=${this.key}`)
  }

}
